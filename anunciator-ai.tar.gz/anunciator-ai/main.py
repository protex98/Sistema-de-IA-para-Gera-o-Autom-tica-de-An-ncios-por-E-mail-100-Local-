from core.ai_generator import AIGenerator
from core.email_sender import EmailSender
from core.database import get_db
from core.models.product import Product
from core.models.customer import Customer
from sqlalchemy.orm import Session
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def run_campaign(db: Session, product_id: int, segment: str = None):
    # 1. Busca informações do produto
    product = db.query(Product).filter(Product.id == product_id).first()
    
    # 2. Busca lista de clientes
    query = db.query(Customer).filter(Customer.is_active == True)
    if segment:
        query = query.filter(Customer.segment == segment)
    customers = query.all()
    
    # 3. Gera o anúncio com IA
    ai = AIGenerator()
    ad_content = ai.generate_ad({
        "name": product.name,
        "description": product.description,
        "features": product.features,
        "target": product.target_audience
    })
    
    # 4. Envia os e-mails
    sender = EmailSender()
    results = []
    for customer in customers:
        success = sender.send_email(
            to_email=customer.email,
            subject=ad_content['subject'],
            body=ad_content['body']
        )
        results.append({"email": customer.email, "success": success})
    
    return results

if __name__ == "__main__":
    db = next(get_db())
    campaign_results = run_campaign(db, product_id=1, segment="premium")
    logger.info(f"Campaign completed with {len(campaign_results)} emails sent")