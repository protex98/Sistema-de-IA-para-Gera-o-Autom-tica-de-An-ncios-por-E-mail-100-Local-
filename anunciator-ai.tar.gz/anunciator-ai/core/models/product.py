from sqlalchemy import Column, Integer, String, Text
from .base import Base

class Product(Base):
    __tablename__ = "products"
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    description = Column(Text)
    features = Column(Text)
    target_audience = Column(String(200))
    category = Column(String(50))