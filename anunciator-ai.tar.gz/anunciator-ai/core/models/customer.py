from sqlalchemy import Column, Integer, String, Text
from .base import Base

class Customer(Base):
    __tablename__ = "customers"
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    email = Column(String(100), unique=True, nullable=False)
    interests = Column(Text)
    segment = Column(String(50))
    is_active = Column(Boolean, default=True)