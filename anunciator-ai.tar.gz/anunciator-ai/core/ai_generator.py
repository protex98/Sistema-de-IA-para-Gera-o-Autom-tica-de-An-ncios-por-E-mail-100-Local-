from llama_cpp import Llama
from config.settings import settings
import json
from typing import Dict

class AIGenerator:
    def __init__(self):
        self.llm = Llama(
            model_path=str(settings.MODEL_PATH),
            n_ctx=settings.LLM_CONTEXT_SIZE,
            n_threads=settings.LLM_THREADS
        )
    
    def generate_ad(self, product_info: Dict, template_type: str = "promotional") -> Dict:
        prompt = self._build_prompt(product_info, template_type)
        response = self.llm.create_completion(
            prompt,
            max_tokens=800,
            temperature=0.7
        )
        return self._parse_response(response)

    def _build_prompt(self, product_info: Dict, template_type: str) -> str:
        # Implementação da construção de prompt
        pass
    
    def _parse_response(self, response) -> Dict:
        # Implementação do parser da resposta
        pass