# Anunciator AI - Gerador de Anúncios por E-mail

Sistema local de IA para criação e envio automático de campanhas de marketing por e-mail.

## Instalação
1. `pip install -r requirements.txt`
2. Configure o arquivo `.env`
3. Execute `python main.py`

## Recursos
- Geração de anúncios com IA local
- Envio por SMTP
- Banco de dados SQLite
- Modelos personalizáveis