import os
from dotenv import load_dotenv
from pathlib import Path

load_dotenv()

class Settings:
    # Configurações de Email
    SMTP_SERVER = os.getenv("SMTP_SERVER")
    SMTP_PORT = int(os.getenv("SMTP_PORT", 587))
    EMAIL_FROM = os.getenv("EMAIL_USER")
    EMAIL_PASSWORD = os.getenv("EMAIL_PASSWORD")
    
    # Configurações de IA
    MODEL_PATH = Path(os.getenv("MODEL_PATH"))
    LLM_CONTEXT_SIZE = 4096
    LLM_THREADS = 4
    
    # Banco de Dados
    DATABASE_URL = f"sqlite:///{os.getenv('DB_PATH')}"

settings = Settings()